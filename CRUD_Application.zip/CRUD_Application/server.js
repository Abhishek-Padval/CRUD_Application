const express = require('express');
require('dotenv').config({path : 'config.env'});
const morgan = require('morgan');
const bodyParser = require('body-parser');
const path = require('path');
const connectDB = require('./server/database/connection');

const app = express();

const PORT = 3000;

 
//log requests
app.use(morgan('tiny'));

// Mongodb Connection
connectDB();

//parse request to body-parser
app.use(bodyParser.urlencoded({ extended: true }));

// set view engine
app.set("view engine","ejs");
//app.set("views engine", path_resolve(__dirname,"views/ejs"))

//load assets

app.use('/css', express.static(path.resolve(__dirname,"assets/style")));
app.use('/img', express.static(path.resolve(__dirname,"assets/img")));
app.use('/js', express.static(path.resolve(__dirname,"assets/index")));


//load routers
app.use('/', require('./server/routes/router')); 


app.listen(PORT,()=> {console.log(`Server is running on http://localhost:${PORT}/`)});
